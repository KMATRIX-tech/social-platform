export type UserStatus = 'active' | 'warned' | 'banned';

export type ProBorderEffect = 'aura-gold' | 'neon-pulse' | 'cosmic-glow' | 'emerald-ring' | 'none';
export type ProAccentColor = 'purple' | 'gold' | 'emerald' | 'neon' | 'crimson';

export interface UserProfile {
  id: string; // Auth UID
  email: string;
  username?: string;
  displayName: string;
  photoURL?: string;
  bio?: string;
  status: UserStatus;
  warningMessage?: string;
  isBanned: boolean;
  savedPostIds?: string[];
  // Administrative and Security Roles
  role?: 'super_admin' | 'sub_admin' | 'user';
  isSubAdmin?: boolean;
  hasBlueStar?: boolean;
  // Pro Subscription Fields
  isPro?: boolean;
  proPlan?: 'monthly' | 'annual';
  proExpiresAt?: string;
  proBadge?: 'verified' | 'vip' | 'creator' | 'founder';
  proBorderEffect?: ProBorderEffect;
  proAccentColor?: ProAccentColor;
  createdAt: string;
  updatedAt?: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorEmail: string;
  authorName: string;
  authorUsername?: string;
  authorPhotoURL?: string;
  content: string;
  imageUrl?: string;
  videoUrl?: string;
  thumbnailUrl?: string;
  hasVideoChunks?: boolean;
  videoFileName?: string;
  mediaType?: 'image' | 'video' | 'none';
  songTitle?: string;
  songArtist?: string;
  songAlbumArt?: string;
  songPreviewUrl?: string;
  songAlbumName?: string;
  likes: string[]; // user IDs
  likesCount: number;
  commentsCount: number;
  savesCount?: number;
  viewsCount?: number;
  isEdited?: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface OnlineSong {
  trackId: number | string;
  trackName: string;
  artistName: string;
  artworkUrl100: string;
  previewUrl: string;
  collectionName?: string;
  primaryGenreName?: string;
}

export interface Spark {
  id: string;
  authorId: string;
  authorEmail: string;
  authorName: string;
  authorUsername?: string;
  authorPhotoURL?: string;
  legendaryTag?: string;
  caption?: string;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  hasVideoChunks?: boolean;
  videoFileName?: string;
  songTitle?: string;
  songArtist?: string;
  songAlbumArt?: string;
  songPreviewUrl?: string;
  likes: string[];
  likesCount: number;
  createdAt: string;
  expiresAt: string;
}

export interface CallRecipient {
  id: string;
  name: string;
  username?: string;
  photoURL?: string;
  email?: string;
}

export interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  authorEmail: string;
  authorName: string;
  authorUsername?: string;
  authorPhotoURL?: string;
  content: string;
  createdAt: string;
}

export interface Announcement {
  id: string;
  authorId: string;
  authorEmail: string;
  authorName: string;
  title: string;
  content: string;
  priority: 'normal' | 'urgent';
  createdAt: string;
}

export type TicketStatus = 'open' | 'in_progress' | 'resolved';

export interface SupportTicket {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  subject: string;
  message: string;
  status: TicketStatus;
  adminReply?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ChannelMessage {
  id: string;
  channelId: string;
  senderId: string;
  senderEmail: string;
  senderName: string;
  senderUsername?: string;
  senderPhotoURL?: string;
  text: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'none';
  gifUrl?: string;
  replyToId?: string;
  replyToText?: string;
  replyToSenderName?: string;
  isEdited?: boolean;
  isDeleted?: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface AppSettings {
  id: string;
  videoCallsUnlocked: boolean;
  voiceCallsUnlocked: boolean;
  updatedAt?: string;
  updatedBy?: string;
}

export interface ChatGroup {
  id: string;
  name: string;
  description?: string;
  logoUrl?: string;
  creatorId: string;
  creatorName: string;
  creatorEmail: string;
  adminIds: string[];
  memberIds: string[];
  createdAt: string;
  updatedAt?: string;
}

export type MobileMoneyProvider = 'airtel' | 'mpesa' | 'tigopesa' | 'azampay';

export interface SubscriptionTier {
  id: 'monthly' | 'annual';
  name: string;
  tagline: string;
  priceTZS: number;
  priceUSD: number;
  billingPeriod: string;
  discountBadge?: string;
  popular?: boolean;
  features: string[];
}

export interface PaymentTransaction {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  planId: 'monthly' | 'annual';
  provider: MobileMoneyProvider;
  phoneNumber: string;
  amountTZS: number;
  amountUSD: number;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  reference: string;
  mpesaReceiptNumber?: string;
  failureReason?: string;
  createdAt: string;
  completedAt?: string;
}

export interface PaymentGatewayConfig {
  id: string;
  environment: 'sandbox' | 'live';
  // Airtel Money API
  airtelClientId?: string;
  airtelClientSecret?: string;
  airtelMerchantCode?: string;
  // Vodacom M-Pesa API
  mpesaConsumerKey?: string;
  mpesaConsumerSecret?: string;
  mpesaPasskey?: string;
  mpesaShortCode?: string;
  // Tigo Pesa / AzamPay / ClickPesa
  tigopesaApiKey?: string;
  azampayClientId?: string;
  azampaySecret?: string;
  azampayAppName?: string;
  azampayApiKey?: string;
  azampayEnv?: 'sandbox' | 'production' | 'live';
  clickpesaApiKey?: string;
  // Webhook security
  webhookSecret?: string;
  updatedAt?: string;
  updatedBy?: string;
}

export type ThemeMode = 'light' | 'dark' | 'system';

export type ActiveTab =
  | 'feed'
  | 'studio'
  | 'videos'
  | 'announcements'
  | 'chat'
  | 'directory'
  | 'analytics'
  | 'admin'
  | 'settings';

