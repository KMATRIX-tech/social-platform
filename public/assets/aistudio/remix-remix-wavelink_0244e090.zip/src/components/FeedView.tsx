import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType, cleanFirestoreData } from '../firebase';
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  doc,
  setDoc,
  deleteDoc,
  addDoc,
  updateDoc,
  limit
} from 'firebase/firestore';
import { Post, PostComment, Announcement } from '../types';
import { CrystalBadge } from './CrystalBadge';
import { VideoPlayer } from './VideoPlayer';
import { SongPlayerCard } from './SongPlayerCard';
import { SparkTray } from './SparkTray';
import {
  Heart,
  MessageCircle,
  Share2,
  Trash2,
  Send,
  Image as ImageIcon,
  Video as VideoIcon,
  Waves,
  Check,
  ShieldCheck,
  Megaphone,
  HelpCircle,
  X,
  Sparkles,
  Flame,
  Bookmark,
  Play,
  UploadCloud,
  Film,
  Clapperboard,
  Music,
  Camera,
  Zap,
  Disc,
  Wand2,
  Edit2,
  Crown,
  Eye
} from 'lucide-react';
import { MobileMoneyPaymentModal } from './MobileMoneyPaymentModal';

interface FeedViewProps {
  onNavigateTab?: (tab: string) => void;
}

export const FeedView: React.FC<FeedViewProps> = ({ onNavigateTab }) => {
  const { currentUser, userProfile, isAdmin, isProEffective, toggleSavePost } = useAuth();
  const isProUser = isProEffective;

  const [posts, setPosts] = useState<Post[]>([]);
  const [latestAnnouncement, setLatestAnnouncement] = useState<Announcement | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Post editing state (WaveLink Pro / Admin privilege)
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [editPostContent, setEditPostContent] = useState('');
  const [isSavingPostEdit, setIsSavingPostEdit] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  // Comments state: map of postId -> PostComment[]
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});
  const [commentsMap, setCommentsMap] = useState<Record<string, PostComment[]>>({});
  const [commentInput, setCommentInput] = useState<Record<string, string>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);


  // Real-time listener for posts
  useEffect(() => {
    const postsQuery = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      postsQuery,
      (snapshot) => {
        const docs: Post[] = [];
        snapshot.forEach((docSnap) => {
          docs.push({ id: docSnap.id, ...docSnap.data() } as Post);
        });
        setPosts(docs);
        setIsLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'posts');
      }
    );

    return () => unsub();
  }, []);

  // Fetch latest announcement for the right rail widget
  useEffect(() => {
    const q = query(collection(db, 'announcements'), orderBy('createdAt', 'desc'), limit(1));
    const unsub = onSnapshot(q, (snap) => {
      if (!snap.empty) {
        setLatestAnnouncement({ id: snap.docs[0].id, ...snap.docs[0].data() } as Announcement);
      } else {
        setLatestAnnouncement(null);
      }
    });
    return () => unsub();
  }, []);

  // Toggle comments expander
  const toggleComments = (postId: string) => {
    setExpandedComments((prev) => ({ ...prev, [postId]: !prev[postId] }));
  };

  useEffect(() => {
    const unsubscribers: (() => void)[] = [];

    Object.keys(expandedComments).forEach((postId) => {
      if (expandedComments[postId]) {
        const commentsRef = collection(db, 'posts', postId, 'comments');
        const q = query(commentsRef, orderBy('createdAt', 'asc'));
        const unsub = onSnapshot(
          q,
          (snap) => {
            const list: PostComment[] = [];
            snap.forEach((d) => list.push({ id: d.id, ...d.data() } as PostComment));
            setCommentsMap((prev) => ({ ...prev, [postId]: list }));
          },
          (err) => {
            console.error('Comments error:', err);
          }
        );
        unsubscribers.push(unsub);
      }
    });

    return () => {
      unsubscribers.forEach((u) => u());
    };
  }, [expandedComments]);

  // Like / Unlike post
  const handleToggleLike = async (post: Post) => {
    if (!currentUser) return;
    const isLiked = post.likes?.includes(currentUser.uid);
    const updatedLikes = isLiked
      ? (post.likes || []).filter((id) => id !== currentUser.uid)
      : [...(post.likes || []), currentUser.uid];

    try {
      await updateDoc(doc(db, 'posts', post.id), {
        likes: updatedLikes,
        likesCount: updatedLikes.length
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `posts/${post.id}`);
    }
  };

  // Save / Bookmark post
  const handleToggleSave = async (postId: string) => {
    await toggleSavePost(postId);
  };

  // Start editing post (Pro or Admin privilege)
  const handleStartEditPost = (post: Post) => {
    setEditingPostId(post.id);
    setEditPostContent(post.content || '');
  };

  // Save edited post
  const handleSavePostEdit = async (postId: string) => {
    if (!editPostContent.trim()) return;
    setIsSavingPostEdit(true);
    try {
      await updateDoc(doc(db, 'posts', postId), {
        content: editPostContent.trim(),
        isEdited: true,
        updatedAt: new Date().toISOString()
      });
      setEditingPostId(null);
      setEditPostContent('');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `posts/${postId}`);
    } finally {
      setIsSavingPostEdit(false);
    }
  };

  // Delete post
  const handleDeletePost = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this wave?')) return;
    try {
      await deleteDoc(doc(db, 'posts', postId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `posts/${postId}`);
    }
  };


  // Add Comment
  const handleAddComment = async (postId: string) => {
    const text = commentInput[postId]?.trim();
    if (!text || !currentUser) return;

    try {
      const commentData = {
        postId,
        authorId: currentUser.uid,
        authorEmail: currentUser.email || '',
        authorName: userProfile?.displayName || currentUser.displayName || 'Waver',
        authorUsername: userProfile?.username || `@${currentUser.email?.split('@')[0] || 'waver'}`,
        authorPhotoURL:
          userProfile?.photoURL ||
          currentUser.photoURL ||
          `https://api.dicebear.com/7.x/shapes/svg?seed=${currentUser.uid}`,
        content: text,
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, 'posts', postId, 'comments'), commentData);

      const post = posts.find((p) => p.id === postId);
      const newCount = (post?.commentsCount || 0) + 1;
      await updateDoc(doc(db, 'posts', postId), {
        commentsCount: newCount
      });

      setCommentInput((prev) => ({ ...prev, [postId]: '' }));
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `posts/${postId}/comments`);
    }
  };

  const copyPostLink = (postId: string) => {
    navigator.clipboard.writeText(`${window.location.origin}/#post-${postId}`);
    setCopiedId(postId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      {/* Vibrant Colorful Welcome Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-violet-600 via-fuchsia-600 to-amber-500 text-white shadow-xl shadow-purple-900/25">
        {/* Ambient floating spheres */}
        <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-cyan-400/30 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 left-1/3 w-40 h-40 rounded-full bg-pink-400/30 blur-2xl pointer-events-none" />

        <div className="relative z-10 flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles size={14} className="text-amber-300 animate-spin" style={{ animationDuration: '6s' }} />
              <span>Explore Community Waves</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Welcome to the WaveFeed, {userProfile?.displayName || 'Friend'}! 🌊
            </h2>
            <p className="text-purple-100 text-xs sm:text-sm mt-1 max-w-xl font-medium">
              Share your moments, post photos & videos from your folders, and connect with real community members.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {onNavigateTab && (
              <button
                onClick={() => onNavigateTab('videos')}
                className="px-4 py-2.5 rounded-2xl bg-white/20 hover:bg-white/30 backdrop-blur-md text-white font-bold text-xs flex items-center gap-2 border border-white/30 transition shadow-sm active:scale-95"
              >
                <VideoIcon size={15} className="text-amber-300" />
                <span>Watch Video Reels</span>
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Main Feed Column */}
        <div className="lg:col-span-8 space-y-6">
          {/* 24-Hour Legendary Moments Spark Tray */}
          <SparkTray />

          {/* Wave Studio Quick Action (Creating & editing posts is now handled in the Studio tab) */}
          <div className="bg-gradient-to-r from-purple-900/30 via-indigo-900/20 to-pink-900/25 border-2 border-purple-200/80 dark:border-purple-800/60 rounded-3xl p-5 shadow-sm flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3.5">
              <div className="p-3 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 text-white shadow-md shadow-purple-600/30">
                <Wand2 size={22} className="text-amber-300" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm sm:text-base text-gray-900 dark:text-white flex items-center gap-1.5">
                  <span>Wave Studio Editor</span>
                  <Sparkles size={14} className="text-amber-400" />
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 max-w-md">
                  Edit photos & videos, add stylish text overlays, vibe stickers, and online soundtracks to publish on the feed!
                </p>
              </div>
            </div>

            {onNavigateTab && (
              <button
                onClick={() => onNavigateTab('studio')}
                className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md shadow-purple-600/25 active:scale-95 transition"
              >
                <Wand2 size={15} />
                <span>Open Media Studio</span>
              </button>
            )}
          </div>

          {/* Posts Stream */}
          <div className="space-y-5">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                <div className="w-8 h-8 border-3 border-purple-600 border-t-transparent rounded-full animate-spin mb-3" />
                <p className="text-xs font-medium">Loading community waves...</p>
              </div>
            ) : posts.length === 0 ? (
              <div className="text-center py-16 px-6 bg-white dark:bg-[#131927] border-2 border-purple-100 dark:border-purple-900/40 rounded-3xl shadow-xs">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-500 to-pink-500 text-white mx-auto flex items-center justify-center mb-4 shadow-lg shadow-purple-500/20">
                  <Waves size={32} />
                </div>
                <h3 className="text-xl font-extrabold text-gray-900 dark:text-white mb-1">
                  Feed Is Clear & Ready!
                </h3>
                <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 max-w-sm mx-auto mb-6 leading-relaxed">
                  WaveLink operates with strict zero mock data. Open the Media Studio to design, edit photos & videos, and post the very first wave!
                </p>
                {onNavigateTab && (
                  <button
                    onClick={() => onNavigateTab('studio')}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-95 text-white font-bold text-xs sm:text-sm shadow-md transition inline-flex items-center gap-2"
                  >
                    <Wand2 size={16} />
                    <span>Open Media Studio</span>
                  </button>
                )}
              </div>
            ) : (
              posts.map((post) => {
                const isLiked = post.likes?.includes(currentUser?.uid || '');
                const isSaved = (userProfile?.savedPostIds || []).includes(post.id);
                const isAuthor = post.authorId === currentUser?.uid;
                const canDelete = isAuthor || isAdmin;
                const canEdit = isAuthor && isProEffective;
                const comments = commentsMap[post.id] || [];
                const isExpanded = !!expandedComments[post.id];

                return (
                  <article
                    key={post.id}
                    className="bg-white dark:bg-[#131927] border border-gray-200/90 dark:border-gray-800 rounded-3xl p-5 sm:p-6 shadow-xs transition hover:border-purple-300 dark:hover:border-purple-900/60"
                  >
                    {/* Author Header */}
                    <div className="flex items-center justify-between mb-3.5">
                      <div className="flex items-center gap-3">
                        <img
                          src={
                            post.authorPhotoURL ||
                            `https://api.dicebear.com/7.x/shapes/svg?seed=${post.authorId}`
                          }
                          alt={post.authorName}
                          className="w-10 h-10 rounded-full object-cover ring-2 ring-purple-500/20"
                        />
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <CrystalBadge
                              email={post.authorEmail}
                              name={post.authorName}
                              size="md"
                            />
                            {post.authorUsername && (
                              <span className="text-xs font-mono text-purple-600 dark:text-purple-400">
                                {post.authorUsername}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 text-xs text-gray-400 mt-0.5">
                            <span className="font-mono tabular-numbers">
                              {new Date(post.createdAt).toLocaleDateString(undefined, {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>Wave</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        {canEdit && (
                          <button
                            onClick={() => handleStartEditPost(post)}
                            className="p-1.5 text-gray-400 hover:text-purple-600 rounded-lg transition"
                            title="Edit Wave Content (Pro Privilege)"
                          >
                            <Edit2 size={15} />
                          </button>
                        )}

                        {canDelete && (
                          <button
                            onClick={() => handleDeletePost(post.id)}
                            className="p-1.5 text-gray-400 hover:text-rose-600 rounded-lg transition"
                            title={isAdmin && !isAuthor ? 'Admin Moderation: Delete' : 'Delete Post'}
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Content or Inline Editor */}
                    {editingPostId === post.id ? (
                      <div className="mb-3.5 p-3 rounded-2xl bg-purple-50/50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800 space-y-2">
                        <textarea
                          rows={3}
                          value={editPostContent}
                          onChange={(e) => setEditPostContent(e.target.value)}
                          className="w-full p-2.5 rounded-xl bg-white dark:bg-gray-800 border border-purple-300 dark:border-purple-700 text-xs sm:text-sm text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                        />
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setEditingPostId(null)}
                            className="px-3 py-1.5 rounded-lg text-xs font-semibold text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            disabled={isSavingPostEdit}
                            onClick={() => handleSavePostEdit(post.id)}
                            className="px-4 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs disabled:opacity-50"
                          >
                            {isSavingPostEdit ? 'Saving...' : 'Save Wave'}
                          </button>
                        </div>
                      </div>
                    ) : (
                      post.content && (
                        <p className="text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap leading-relaxed mb-3.5">
                          {post.content}
                          {post.isEdited && (
                            <span className="text-[10px] text-gray-400 italic ml-2">
                              (edited)
                            </span>
                          )}
                        </p>
                      )
                    )}


                    {/* Attached Online Song Soundtrack */}
                    {post.songPreviewUrl && post.songTitle && (
                      <div className="mb-3.5">
                        <SongPlayerCard
                          title={post.songTitle}
                          artist={post.songArtist || ''}
                          albumArt={post.songAlbumArt}
                          previewUrl={post.songPreviewUrl}
                          albumName={post.songAlbumName}
                        />
                      </div>
                    )}

                    {/* Attached Video from Folders / Community Hub */}
                    {(post.videoUrl || post.hasVideoChunks || post.mediaType === 'video') && (
                      <div className="mb-3.5">
                        <VideoPlayer
                          postId={post.id}
                          videoUrl={post.videoUrl}
                          hasVideoChunks={post.hasVideoChunks}
                        />
                      </div>
                    )}

                    {/* Attached Image from Folders */}
                    {post.imageUrl && !post.videoUrl && !post.hasVideoChunks && post.mediaType !== 'video' && (
                      <div className="rounded-2xl overflow-hidden mb-3.5 border border-gray-100 dark:border-gray-800 max-h-96 bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
                        <img
                          src={post.imageUrl}
                          alt="Wave attachment"
                          className="w-full h-auto max-h-96 object-cover"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      </div>
                    )}

                    {/* Action Bar */}
                    <div className="flex items-center justify-between pt-3 border-t border-gray-100 dark:border-gray-800 text-xs font-semibold text-gray-500 dark:text-gray-400">
                      <div className="flex items-center gap-3">
                        {/* Like */}
                        <button
                          onClick={() => handleToggleLike(post)}
                          className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl transition active:scale-95 ${
                            isLiked
                              ? 'text-rose-600 bg-rose-50 dark:bg-rose-950/40 font-bold'
                              : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                          }`}
                        >
                          <Heart size={16} className={isLiked ? 'fill-rose-600 text-rose-600' : ''} />
                          <span className="font-mono tabular-numbers">{post.likesCount || 0}</span>
                        </button>

                        {/* Comments */}
                        <button
                          onClick={() => toggleComments(post.id)}
                          className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl transition ${
                            isExpanded
                              ? 'text-purple-600 bg-purple-50 dark:bg-purple-950/40'
                              : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                          }`}
                        >
                          <MessageCircle size={16} />
                          <span className="font-mono tabular-numbers">{post.commentsCount || 0} Replies</span>
                        </button>

                        {/* Save / Bookmark */}
                        <button
                          onClick={() => handleToggleSave(post.id)}
                          className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl transition active:scale-95 ${
                            isSaved
                              ? 'text-purple-600 bg-purple-50 dark:bg-purple-950/40 font-bold'
                              : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                          }`}
                          title={isSaved ? 'Saved to bookmarks' : 'Save post'}
                        >
                          <Bookmark size={16} className={isSaved ? 'fill-purple-600 text-purple-600' : ''} />
                          <span className="font-mono tabular-numbers">{post.savesCount || 0}</span>
                        </button>
                      </div>

                      <button
                        onClick={() => copyPostLink(post.id)}
                        className="flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition"
                      >
                        {copiedId === post.id ? (
                          <Check size={14} className="text-emerald-500" />
                        ) : (
                          <Share2 size={14} />
                        )}
                        <span>{copiedId === post.id ? 'Copied' : 'Share'}</span>
                      </button>
                    </div>

                    {/* Collapsible Comments Section */}
                    {isExpanded && (
                      <div className="mt-4 pt-3.5 border-t border-gray-100 dark:border-gray-800 space-y-3">
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            value={commentInput[post.id] || ''}
                            onChange={(e) =>
                              setCommentInput((prev) => ({ ...prev, [post.id]: e.target.value }))
                            }
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleAddComment(post.id);
                            }}
                            placeholder="Write a reply..."
                            className="flex-1 py-2 px-3.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-xs text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                          <button
                            onClick={() => handleAddComment(post.id)}
                            disabled={!commentInput[post.id]?.trim()}
                            className="p-2 rounded-xl bg-purple-600 text-white disabled:opacity-40 hover:bg-purple-700 transition"
                          >
                            <Send size={14} />
                          </button>
                        </div>

                        {comments.length === 0 ? (
                          <p className="text-[11px] text-gray-400 italic py-1">
                            No replies yet. Be the first to chime in!
                          </p>
                        ) : (
                          <div className="space-y-2 pt-1">
                            {comments.map((comment) => (
                              <div
                                key={comment.id}
                                className="flex items-start gap-2.5 p-3 rounded-2xl bg-gray-50/70 dark:bg-gray-800/40 text-xs"
                              >
                                <img
                                  src={
                                    comment.authorPhotoURL ||
                                    `https://api.dicebear.com/7.x/shapes/svg?seed=${comment.authorId}`
                                  }
                                  alt={comment.authorName}
                                  className="w-7 h-7 rounded-full object-cover ring-1 ring-purple-500/20 shrink-0 mt-0.5"
                                />
                                <div className="flex-1">
                                  <div className="flex items-center justify-between">
                                    <CrystalBadge
                                      email={comment.authorEmail}
                                      name={comment.authorName}
                                      size="sm"
                                    />
                                    <span className="text-[10px] text-gray-400 font-mono tabular-numbers">
                                      {new Date(comment.createdAt).toLocaleTimeString([], {
                                        hour: '2-digit',
                                        minute: '2-digit'
                                      })}
                                    </span>
                                  </div>
                                  <p className="mt-1 text-gray-700 dark:text-gray-300 leading-relaxed">
                                    {comment.content}
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </article>
                );
              })
            )}
          </div>
        </div>

        {/* Right Rail Contextual Widget (Desktop Only) */}
        <div className="hidden lg:block lg:col-span-4 space-y-5 sticky top-22">
          {/* Quick Hub Shortcut Card */}
          <div className="bg-gradient-to-br from-purple-900 to-indigo-950 text-white rounded-3xl p-5 shadow-md">
            <div className="flex items-center gap-2 mb-2 text-pink-300 font-bold text-xs uppercase tracking-wider">
              <Film size={16} />
              <span>Wave Reels Hub</span>
            </div>
            <h4 className="font-extrabold text-base mb-1">
              Watch Community Videos
            </h4>
            <p className="text-xs text-purple-200/80 leading-relaxed mb-4">
              Browse, like, and save all video waves uploaded by members from their folders.
            </p>
            {onNavigateTab && (
              <button
                onClick={() => onNavigateTab('videos')}
                className="w-full py-2.5 px-4 rounded-xl bg-white text-purple-900 font-bold text-xs hover:bg-purple-50 transition shadow-sm"
              >
                Open Video Reels →
              </button>
            )}
          </div>

          {/* Platform Authenticity Card */}
          <div className="bg-white dark:bg-[#131927] border border-gray-200/90 dark:border-gray-800 rounded-3xl p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-2 text-purple-600 dark:text-purple-400 font-bold text-xs uppercase tracking-wider">
              <ShieldCheck size={16} />
              <span>Platform Integrity</span>
            </div>
            <h4 className="font-bold text-sm text-gray-900 dark:text-white mb-1">
              Real Authenticated Network
            </h4>
            <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
              WaveLink guarantees 0% synthetic bot profiles or seeded mock threads. All activity originates from verified accounts.
            </p>
          </div>

          {/* Latest Platform Announcement Widget */}
          {latestAnnouncement ? (
            <div className="bg-gradient-to-br from-purple-900/10 to-indigo-900/10 dark:from-purple-950/40 dark:to-indigo-950/30 border border-purple-200 dark:border-purple-900/60 rounded-3xl p-5 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400 flex items-center gap-1">
                  <Megaphone size={12} />
                  <span>Latest Bulletin</span>
                </span>
                <span className="text-[10px] text-gray-400 font-mono tabular-numbers">
                  {new Date(latestAnnouncement.createdAt).toLocaleDateString()}
                </span>
              </div>
              <h4 className="font-bold text-sm text-gray-900 dark:text-white mb-1">
                {latestAnnouncement.title}
              </h4>
              <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-2 mb-3">
                {latestAnnouncement.content}
              </p>
              {onNavigateTab && (
                <button
                  onClick={() => onNavigateTab('announcements')}
                  className="text-xs font-bold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1"
                >
                  <span>View All Bulletins →</span>
                </button>
              )}
            </div>
          ) : null}

          {/* WaveLink Pro Promotion / Creator Analytics Card */}
          <div className="bg-gradient-to-br from-purple-950 via-indigo-950 to-slate-900 border border-purple-500/30 text-white rounded-3xl p-5 shadow-lg relative overflow-hidden">
            <div className="flex items-center gap-2 mb-2 text-amber-300 font-extrabold text-xs uppercase tracking-wider">
              <Crown size={15} />
              <span>WaveLink Pro VIP</span>
            </div>
            <h4 className="font-extrabold text-base mb-1">
              {isProUser ? 'Creator Analytics Active' : 'Upgrade to WaveLink Pro'}
            </h4>
            <p className="text-xs text-purple-200/80 leading-relaxed mb-4">
              {isProUser
                ? 'Check your wave impressions, weekly audience reach, and engagement ratios in real-time.'
                : 'Get verified badges, glowing aura rings, 500MB uploads, and Mobile Money billing (Airtel / M-Pesa).'}
            </p>

            <button
              onClick={() => {
                if (isProUser && onNavigateTab) {
                  onNavigateTab('analytics');
                } else {
                  setIsPaymentModalOpen(true);
                }
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-purple-600 to-pink-500 hover:opacity-95 text-white font-extrabold text-xs transition shadow-md shadow-purple-950/40 flex items-center justify-center gap-2"
            >
              <Sparkles size={14} />
              <span>{isProUser ? 'Open Creator Analytics →' : 'Upgrade from TZS 12,000 →'}</span>
            </button>
          </div>

          {/* Support Ticket Quick Link */}
          <div className="bg-white dark:bg-[#131927] border border-gray-200/90 dark:border-gray-800 rounded-3xl p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-1 text-gray-900 dark:text-white font-bold text-sm">
              <HelpCircle size={16} className="text-purple-600" />
              <span>Need Assistance?</span>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-3 leading-relaxed">
              Have an issue, feature suggestion, or account concern? Submit a confidential ticket directly to the admin in Settings.
            </p>
            {onNavigateTab && (
              <button
                onClick={() => onNavigateTab('settings')}
                className="w-full py-2 px-3 rounded-xl bg-gray-50 hover:bg-gray-100 dark:bg-gray-800 dark:hover:bg-gray-700/80 text-purple-700 dark:text-purple-300 text-xs font-semibold border border-purple-200/60 dark:border-purple-800/60 transition"
              >
                Open Helpdesk in Settings
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Money Payment Modal */}
      {isPaymentModalOpen && (
        <MobileMoneyPaymentModal
          onClose={() => setIsPaymentModalOpen(false)}
          onSuccess={() => setIsPaymentModalOpen(false)}
        />
      )}
    </div>
  );
};

