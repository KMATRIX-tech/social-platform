import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { CrystalBadge } from './CrystalBadge';
import { ActiveTab } from '../types';
import {
  Waves,
  Rss,
  Film,
  Megaphone,
  MessageSquare,
  Users,
  Shield,
  Settings,
  LogOut,
  Sun,
  Moon,
  Laptop,
  X,
  Wand2,
  BarChart3,
  Crown,
  Sparkles
} from 'lucide-react';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpenMobile,
  onCloseMobile
}) => {
  const { currentUser, userProfile, isAdmin, isSuperAdmin, isSubAdmin, isProEffective, signOut } = useAuth();
  const { theme, setTheme } = useTheme();

  const isProUser = isProEffective;

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'feed', label: 'Wave Feed', icon: <Rss size={18} /> },
    { id: 'studio', label: 'Media Studio', icon: <Wand2 size={18} />, badge: '500MB' },
    { id: 'videos', label: 'Wave Reels', icon: <Film size={18} /> },
    { id: 'announcements', label: 'Announcements', icon: <Megaphone size={18} /> },
    { id: 'chat', label: 'Messaging & Groups', icon: <MessageSquare size={18} /> },
    { id: 'directory', label: 'Members', icon: <Users size={18} /> },
    { id: 'analytics', label: 'Creator Analytics', icon: <BarChart3 size={18} />, badge: isProUser ? 'Pro' : undefined },
    // Restrict Admin / Moderator Desk to authorized admins
    ...(isAdmin
      ? [{
          id: 'admin' as ActiveTab,
          label: isSuperAdmin ? 'Admin Desk' : 'Moderator Desk',
          icon: <Shield size={18} />,
          badge: isSuperAdmin ? 'Owner' : 'Mod'
        }]
      : []),
    { id: 'settings', label: 'Settings & Pro', icon: <Settings size={18} /> },
  ];


  const handleSelectTab = (tab: ActiveTab) => {
    setActiveTab(tab);
    onCloseMobile();
  };

  const cycleTheme = () => {
    if (theme === 'light') setTheme('dark');
    else if (theme === 'dark') setTheme('system');
    else setTheme('light');
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-white dark:bg-[#0f1422] border-r border-gray-200/80 dark:border-gray-800 transition-colors select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-gray-100 dark:border-gray-800/80 flex items-center justify-between">
        <div
          onClick={() => handleSelectTab('feed')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 text-white shadow-md shadow-purple-500/25 group-hover:scale-105 transition-transform">
            <Waves size={22} />
          </div>
          <div className="flex flex-col">
            <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-500 bg-clip-text text-transparent">
              WaveLink
            </span>
            <span className="text-[10px] font-semibold text-gray-400 dark:text-gray-500 -mt-0.5">
              Connect & Share
            </span>
          </div>
        </div>

        {isOpenMobile && (
          <button
            onClick={onCloseMobile}
            className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg lg:hidden"
          >
            <X size={18} />
          </button>
        )}
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-3.5 py-4 space-y-1">
        <div className="text-[10px] font-bold uppercase tracking-wider text-gray-400 dark:text-gray-500 px-3 py-1 mb-1">
          Menu
        </div>

        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const isItemAdmin = item.id === 'admin';

          return (
            <button
              key={item.id}
              onClick={() => handleSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold transition-all duration-150 ${
                isActive
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/25 dark:bg-purple-600'
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100/80 dark:hover:bg-gray-800/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={isActive ? 'text-white' : 'text-gray-500 dark:text-gray-400'}>
                  {item.icon}
                </span>
                <span>{item.label}</span>
              </div>

              {item.badge && (
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : isItemAdmin && isAdmin
                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                      : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* WaveLink Pro Mini Shortcut Card */}
      {!isProUser && (
        <div className="p-3.5 mx-3 mb-2 rounded-2xl bg-gradient-to-r from-amber-500/15 via-purple-500/15 to-indigo-500/15 border border-purple-500/30 flex items-center justify-between gap-2">
          <div className="min-w-0">
            <span className="text-[10px] font-black uppercase text-amber-500 tracking-wider flex items-center gap-1">
              <Crown size={11} /> WaveLink Pro
            </span>
            <p className="text-[11px] text-gray-600 dark:text-gray-300 font-semibold truncate">
              500MB & 1080p Stream
            </p>
          </div>
          <button
            onClick={() => handleSelectTab('settings')}
            className="px-2.5 py-1 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-[10px] font-bold shadow-xs transition shrink-0"
          >
            Upgrade
          </button>
        </div>
      )}

      {/* User Account Footer */}
      <div className="p-3.5 border-t border-gray-100 dark:border-gray-800/80 bg-gray-50/50 dark:bg-[#0c101c]/50">
        <div className="flex items-center justify-between gap-2 p-2 rounded-2xl bg-white dark:bg-gray-800/70 border border-gray-200/60 dark:border-gray-700/60 shadow-2xs">
          <div
            onClick={() => handleSelectTab('settings')}
            className="flex items-center gap-2.5 cursor-pointer min-w-0 flex-1"
          >
            <img
              src={
                userProfile?.photoURL ||
                currentUser?.photoURL ||
                `https://api.dicebear.com/7.x/shapes/svg?seed=${currentUser?.uid || 'user'}`
              }
              alt="Avatar"
              className={`w-9 h-9 rounded-full object-cover shrink-0 ${
                userProfile?.isPro
                  ? 'pro-aura-gold ring-2 ring-amber-400'
                  : 'ring-2 ring-purple-500/20'
              }`}
            />
            <div className="min-w-0 flex-1">
              <div className="truncate">
                <CrystalBadge
                  email={currentUser?.email}
                  name={userProfile?.displayName || currentUser?.displayName || 'Waver'}
                  isPro={userProfile?.isPro}
                  hasBlueStar={isProUser}
                  isSubAdmin={isSubAdmin}
                  size="sm"
                  showAdminTag={isAdmin}
                />
              </div>
              <div className="text-[10px] text-gray-400 truncate">
                {currentUser?.email}
              </div>
            </div>
          </div>


          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={cycleTheme}
              title={`Switch Theme (Current: ${theme})`}
              className="p-1.5 text-gray-500 hover:text-purple-600 dark:hover:text-purple-400 rounded-lg transition"
            >
              {theme === 'light' ? (
                <Sun size={15} className="text-amber-500" />
              ) : theme === 'dark' ? (
                <Moon size={15} className="text-purple-400" />
              ) : (
                <Laptop size={15} className="text-blue-500" />
              )}
            </button>

            <button
              onClick={signOut}
              title="Sign Out"
              className="p-1.5 text-gray-400 hover:text-rose-600 rounded-lg transition"
            >
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Fixed Sidebar */}
      <aside className="hidden lg:block w-64 xl:w-72 shrink-0 h-screen sticky top-0 z-30">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Overlay */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
          />
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10 animate-slide-right">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
