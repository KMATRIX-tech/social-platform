import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { ActiveTab } from '../types';
import {
  Menu,
  Sun,
  Moon,
  Laptop,
  Waves
} from 'lucide-react';

interface TopHeaderProps {
  activeTab: ActiveTab;
  onOpenMobileMenu: () => void;
}

const TAB_TITLES: Record<ActiveTab, { title: string; subtitle: string }> = {
  feed: { title: 'Wave Feed', subtitle: 'Community social waves and photos' },
  studio: { title: 'Media Studio', subtitle: 'Create, edit photos & videos with text, filters and music' },
  videos: { title: 'Wave Reels & Videos', subtitle: 'Watch, like, save, and share community clips' },
  announcements: { title: 'Global Announcements', subtitle: 'Official platform broadcasts' },
  chat: { title: 'Chat & Groups', subtitle: 'Direct 1-on-1 messaging & user-created group chats' },
  directory: { title: 'Members Directory', subtitle: 'Real verified community members' },
  analytics: { title: 'Creator Analytics', subtitle: 'Wave impressions, engagement ratios & reach' },
  admin: { title: 'Admin Desk', subtitle: 'Restricted system governance console' },
  settings: { title: 'Settings & Pro', subtitle: 'Account preferences, subscriptions and helpdesk' },
};


export const TopHeader: React.FC<TopHeaderProps> = ({
  activeTab,
  onOpenMobileMenu
}) => {
  const { isAdmin, isSuperAdmin } = useAuth();
  const { theme, setTheme } = useTheme();

  const cycleTheme = () => {
    if (theme === 'light') setTheme('dark');
    else if (theme === 'dark') setTheme('system');
    else setTheme('light');
  };

  const currentTabInfo = TAB_TITLES[activeTab] || { title: 'WaveLink', subtitle: 'Social Platform' };

  return (
    <header className="sticky top-0 z-20 w-full backdrop-blur-md bg-white/90 dark:bg-[#0B0F19]/90 border-b border-gray-200/80 dark:border-gray-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Left: Mobile Menu button & View Title */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenMobileMenu}
              className="p-2 -ml-2 rounded-xl text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 lg:hidden"
              title="Open Navigation"
            >
              <Menu size={20} />
            </button>

            <div className="flex items-center gap-2 lg:hidden">
              <div className="p-1.5 rounded-xl bg-purple-600 text-white">
                <Waves size={16} />
              </div>
              <span className="font-extrabold text-base tracking-tight bg-gradient-to-r from-purple-600 to-pink-500 bg-clip-text text-transparent">
                WaveLink
              </span>
            </div>

            <div className="hidden lg:flex flex-col">
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-lg text-gray-900 dark:text-white tracking-tight">
                  {currentTabInfo.title}
                </h1>
                {activeTab === 'admin' && (
                  <span
                    className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      isSuperAdmin
                        ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300 ring-1 ring-purple-400/40'
                        : isAdmin
                        ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 ring-1 ring-indigo-400/40'
                        : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                    }`}
                  >
                    {isSuperAdmin ? 'Platform Owner' : isAdmin ? 'Sub-Admin (Mod)' : 'Guarded (403)'}
                  </span>
                )}
              </div>
              <span className="text-[11px] text-gray-500 dark:text-gray-400 -mt-0.5 font-medium">
                {currentTabInfo.subtitle}
              </span>
            </div>
          </div>

          {/* Right: Smooth Theme switcher pill */}
          <div className="flex items-center gap-2">
            <button
              onClick={cycleTheme}
              title={`Switch Appearance (Current: ${theme})`}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-700 flex items-center gap-2 transition active:scale-95 shadow-2xs"
            >
              {theme === 'light' ? (
                <>
                  <Sun size={15} className="text-amber-500" />
                  <span className="hidden sm:inline">Light Mode</span>
                </>
              ) : theme === 'dark' ? (
                <>
                  <Moon size={15} className="text-purple-400" />
                  <span className="hidden sm:inline">Dark Mode</span>
                </>
              ) : (
                <>
                  <Laptop size={15} className="text-blue-500" />
                  <span className="hidden sm:inline">Auto (Device)</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
