import React from 'react';
import { ActiveTab } from '../types';
import { Rss, Film, MessageSquare, Users, Settings, Wand2 } from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ activeTab, setActiveTab }) => {
  const items: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'feed', label: 'Feed', icon: <Rss size={18} /> },
    { id: 'studio', label: 'Studio', icon: <Wand2 size={18} /> },
    { id: 'videos', label: 'Reels', icon: <Film size={18} /> },
    { id: 'chat', label: 'Chat', icon: <MessageSquare size={18} /> },
    { id: 'directory', label: 'Users', icon: <Users size={18} /> },
    { id: 'settings', label: 'Settings', icon: <Settings size={18} /> },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-[#0B0F19]/95 backdrop-blur-md border-t border-gray-200/80 dark:border-gray-800 transition-colors shadow-lg">
      <div className="flex items-center justify-around h-15 px-2">
        {items.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
                isActive
                  ? 'text-purple-600 dark:text-purple-400 font-bold'
                  : 'text-gray-400 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <div className="p-1 rounded-xl">
                {item.icon}
              </div>
              <span className="text-[10px] tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
