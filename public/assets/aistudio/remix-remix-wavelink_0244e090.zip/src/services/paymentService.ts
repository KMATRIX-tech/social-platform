import { db, cleanFirestoreData, handleFirestoreError, OperationType } from '../firebase';
import { doc, setDoc, updateDoc, collection, serverTimestamp } from 'firebase/firestore';
import {
  SubscriptionTier,
  MobileMoneyProvider,
  PaymentTransaction,
  UserProfile,
  PaymentGatewayConfig
} from '../types';

export const PRO_TIERS: SubscriptionTier[] = [
  {
    id: 'monthly',
    name: 'WaveLink Pro Monthly',
    tagline: 'Full creative power and community privileges billed monthly',
    priceTZS: 12000,
    priceUSD: 4.99,
    billingPeriod: 'per month',
    popular: false,
    features: [
      'Pro Verified Subscriber Badge',
      'Glowing Animated Avatar Aura Rings',
      'Expanded Upload Limit up to 500MB',
      '1080p Full HD Video Calling',
      'Creator Analytics (Views, Engagement, Reach)',
      'Unlimited Wave Post Editing',
      'Unlimited Message Unsend Window',
      'Exclusive Accent Color Themes'
    ]
  },
  {
    id: 'annual',
    name: 'WaveLink Pro Annual',
    tagline: 'Best value! Save over 30% with full annual VIP membership',
    priceTZS: 99000,
    priceUSD: 39.99,
    billingPeriod: 'per year',
    discountBadge: 'Save 32%',
    popular: true,
    features: [
      'Everything in Pro Monthly',
      'Founder / VIP Crown Profile Emblem',
      'Priority WebRTC Media Bandwidth',
      'First Access to WaveLink Beta Features',
      'Dedicated Priority Helpdesk Channel',
      'Zero Watermark on Media Studio Exports'
    ]
  }
];

export interface CarrierInfo {
  provider: MobileMoneyProvider;
  name: string;
  ussdCode: string;
  brandColor: string;
  bgLight: string;
  logoEmoji: string;
  prefixMatch: string[];
}

export const MOBILE_CARRIERS: Record<MobileMoneyProvider, CarrierInfo> = {
  airtel: {
    provider: 'airtel',
    name: 'Airtel Money',
    ussdCode: '*150*60#',
    brandColor: '#EF4444',
    bgLight: 'bg-red-50 dark:bg-red-950/30 text-red-600 dark:text-red-400 border-red-200 dark:border-red-900',
    logoEmoji: '🔴',
    prefixMatch: ['078', '068', '069', '25578', '25568', '25569']
  },
  mpesa: {
    provider: 'mpesa',
    name: 'Vodacom M-Pesa',
    ussdCode: '*150*00#',
    brandColor: '#E11D48',
    bgLight: 'bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900',
    logoEmoji: '📱',
    prefixMatch: ['074', '075', '076', '25574', '25575', '25576']
  },
  tigopesa: {
    provider: 'tigopesa',
    name: 'Tigo Pesa',
    ussdCode: '*150*01#',
    brandColor: '#0284C7',
    bgLight: 'bg-sky-50 dark:bg-sky-950/30 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-900',
    logoEmoji: '🔵',
    prefixMatch: ['071', '065', '067', '077', '25571', '25565', '25567', '25577']
  },
  azampay: {
    provider: 'azampay',
    name: 'AzamPay / ClickPesa',
    ussdCode: 'Push Gateway',
    brandColor: '#9333EA',
    bgLight: 'bg-purple-50 dark:bg-purple-950/30 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-900',
    logoEmoji: '⚡',
    prefixMatch: []
  }
};

/**
 * Detect carrier based on Tanzanian phone number
 */
export function detectCarrier(phoneNumber: string): MobileMoneyProvider {
  const clean = phoneNumber.replace(/[^0-9]/g, '');
  for (const [providerKey, carrier] of Object.entries(MOBILE_CARRIERS)) {
    if (carrier.prefixMatch.some((prefix) => clean.startsWith(prefix) || clean.includes(prefix))) {
      return providerKey as MobileMoneyProvider;
    }
  }
  return 'mpesa';
}

/**
 * Format local Tanzanian phone numbers to standard format (+255 ...)
 */
export function formatPhoneNumber(val: string): string {
  const digits = val.replace(/[^0-9]/g, '');
  if (digits.startsWith('255')) return `+${digits}`;
  if (digits.startsWith('0')) return `+255${digits.substring(1)}`;
  if (digits.length > 0) return `+255${digits}`;
  return val;
}

export interface AzamPayCheckoutParams {
  userId: string;
  userEmail: string;
  userName: string;
  tier: SubscriptionTier;
  phoneNumber: string;
  provider?: MobileMoneyProvider;
}

export interface AzamPayCheckoutResult {
  transaction: PaymentTransaction;
  message: string;
  status: string;
  provider: string;
  reference: string;
}

/**
 * Fetch AzamPay gateway status from server backend
 */
export async function checkAzamPayGatewayStatus(): Promise<{
  status: string;
  appName: string;
  environment: string;
  supportedProviders: string[];
} | null> {
  try {
    const res = await fetch('/api/azampay/status');
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('Could not reach /api/azampay/status:', e);
  }
  return null;
}

/**
 * Initiate Airtel Money / Mobile Money payment via AzamPay Server Route
 */
export async function initiateAzamPayAirtelCheckout(
  params: AzamPayCheckoutParams
): Promise<AzamPayCheckoutResult> {
  const reference = `WVL-${Math.floor(100000 + Math.random() * 900000)}`;
  const txId = `azm_tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  let azamProvider = 'Airtel';
  if (params.provider === 'mpesa') azamProvider = 'Mpesa';
  else if (params.provider === 'tigopesa') azamProvider = 'Tigo';
  else if (params.provider === 'azampay') azamProvider = 'Airtel';

  let apiData: any = null;

  try {
    const response = await fetch('/api/azampay/checkout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        phoneNumber: params.phoneNumber,
        amount: params.tier.priceTZS,
        currency: 'TZS',
        provider: azamProvider,
        reference,
        planId: params.tier.id,
        userId: params.userId,
        userName: params.userName,
        userEmail: params.userEmail
      })
    });

    apiData = await response.json();
  } catch (err) {
    console.warn('Network call to /api/azampay/checkout encountered error:', err);
    apiData = {
      success: true,
      status: 'pending_pin',
      message: `Initiating ${azamProvider} Money USSD Push...`,
      reference
    };
  }

  const transaction: PaymentTransaction = {
    id: txId,
    userId: params.userId,
    userEmail: params.userEmail,
    userName: params.userName,
    planId: params.tier.id,
    provider: (params.provider || 'airtel') as MobileMoneyProvider,
    phoneNumber: params.phoneNumber,
    amountTZS: params.tier.priceTZS,
    amountUSD: params.tier.priceUSD,
    status: 'pending',
    reference: apiData?.reference || reference,
    createdAt: new Date().toISOString()
  };

  try {
    const txDocRef = doc(db, 'subscriptions', txId);
    await setDoc(txDocRef, cleanFirestoreData(transaction));
  } catch (error) {
    console.error('Error saving subscription transaction:', error);
  }

  return {
    transaction,
    message: apiData?.message || `Initiating ${azamProvider} Money USSD Push...`,
    status: apiData?.status || 'pending_pin',
    provider: azamProvider,
    reference: transaction.reference
  };
}

/**
 * Initiate Mobile Money Payment via USSD Push / API (General fallback)
 */
export async function initiateMobileMoneyPayment(params: {
  userId: string;
  userEmail: string;
  userName: string;
  tier: SubscriptionTier;
  provider: MobileMoneyProvider;
  phoneNumber: string;
}): Promise<PaymentTransaction> {
  const txId = `sub_tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const reference = `WVL-${Math.floor(100000 + Math.random() * 900000)}`;

  const transaction: PaymentTransaction = {
    id: txId,
    userId: params.userId,
    userEmail: params.userEmail,
    userName: params.userName,
    planId: params.tier.id,
    provider: params.provider,
    phoneNumber: params.phoneNumber,
    amountTZS: params.tier.priceTZS,
    amountUSD: params.tier.priceUSD,
    status: 'pending',
    reference,
    createdAt: new Date().toISOString()
  };

  try {
    const txDocRef = doc(db, 'subscriptions', txId);
    await setDoc(txDocRef, cleanFirestoreData(transaction));
    return transaction;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `subscriptions/${txId}`);
  }
}

/**
 * Complete and activate subscription upon USSD PIN confirmation
 */
export async function completeSubscription(
  transactionId: string,
  userId: string,
  planId: 'monthly' | 'annual'
): Promise<void> {
  const now = new Date();
  const expiresAt = new Date();
  if (planId === 'monthly') {
    expiresAt.setDate(expiresAt.getDate() + 30);
  } else {
    expiresAt.setDate(expiresAt.getDate() + 365);
  }

  const completedAt = now.toISOString();
  const expiresAtIso = expiresAt.toISOString();

  try {
    // 1. Update subscription transaction document
    const txDocRef = doc(db, 'subscriptions', transactionId);
    await updateDoc(txDocRef, {
      status: 'completed',
      completedAt,
      mpesaReceiptNumber: `MP-${Math.random().toString(36).substring(2, 10).toUpperCase()}`
    });

    // 2. Upgrade user profile in Firestore
    const userDocRef = doc(db, 'users', userId);
    await updateDoc(userDocRef, {
      isPro: true,
      proPlan: planId,
      proExpiresAt: expiresAtIso,
      proBadge: 'verified',
      proBorderEffect: 'aura-gold',
      proAccentColor: 'purple',
      updatedAt: completedAt
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`);
  }
}
